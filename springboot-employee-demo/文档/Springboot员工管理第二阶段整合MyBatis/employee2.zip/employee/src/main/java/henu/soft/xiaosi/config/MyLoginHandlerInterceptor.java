package henu.soft.xiaosi.config;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 自定义拦截器组件
 */

public class MyLoginHandlerInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        Object loginUser = request.getSession().getAttribute("loginUser");
        if(loginUser == null){
            //没有登录
            request.setAttribute("msg","请登录后操作！");
            request.getRequestDispatcher("/").forward(request,response);
            return false;
        }
        else{

            return true;
        }
    }
}
