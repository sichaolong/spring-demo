package henu.soft.xiaosi.controller;

import henu.soft.xiaosi.dao.DepartmentDao;
import henu.soft.xiaosi.dao.EmployeeDao;
import henu.soft.xiaosi.pojo.Department;
import henu.soft.xiaosi.pojo.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Collection;

@Controller
public class EmployeeController {

    @Autowired
    private EmployeeDao employeeDao;

    @Autowired
    DepartmentDao departmentDao;

    @RequestMapping("/emps")
    public String list(Model model){
        Collection<Employee> employees = employeeDao.getAll();
        model.addAttribute("emps",employees);
        return "emp/list";
    }

    //转到添加的表单
    @GetMapping("/add")
    public String toAddPage(Model model){

        //部门信息数据回显
        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("departments",departments);
        return "emp/add";
    }
    //添加员工
    @PostMapping("/add")
    public String adding(Employee employee){
        employeeDao.save(employee);

        return "redirect:/emps";

    }
    @RequestMapping("/edit/{id}")
    public String edit(@PathVariable("id") int id,Model model){
        //数据回显
        Employee employee = employeeDao.getEmployeeById(id);
        model.addAttribute("employee",employee);
        Department department = departmentDao.getDepartmentById(id);
        model.addAttribute("department",department);

        Collection<Department> departments = departmentDao.getDepartments();
        model.addAttribute("departments",departments);
        return "/emp/edit";


    }
    @RequestMapping("/delete/{id}")
    public String delete(@PathVariable("id") Integer id){

        employeeDao.delete(id);
        return "redirect:/emps";


    }


}
