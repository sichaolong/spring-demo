csdn:

	MongoDB初步使用1_快速使用、文章评论小案例

	https://blog.csdn.net/qq_24654501/article/details/113619072

GitHub:

	study-mongodb_demo1
	https://github.com/GitHubSi/study-mongodb_demo1